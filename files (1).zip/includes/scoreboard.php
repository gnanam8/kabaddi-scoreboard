<div class="kabaddi-scoreboard">
    <div class="team">
        <div class="team-name">Home</div>
        <div id="home-score" class="score">0</div>
        <div class="controls">
            <button id="home-increment">+</button>
            <button id="home-decrement">-</button>
        </div>
    </div>
    <div class="team">
        <div class="team-name">Guest</div>
        <div id="guest-score" class="score">0</div>
        <div class="controls">
            <button id="guest-increment">+</button>
            <button id="guest-decrement">-</button>
        </div>
    </div>
</div>
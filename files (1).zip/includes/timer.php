<div class="kabaddi-timer">
    <div id="timer-display">00:00</div>
    <div class="controls">
        <button id="start-timer">Start</button>
        <button id="stop-timer">Stop</button>
        <button id="reset-timer">Reset</button>
    </div>
</div>

<script>
jQuery(document).ready(function ($) {
    let timer;
    let time = 0;

    function updateTimerDisplay() {
        let minutes = Math.floor(time / 60);
        let seconds = time % 60;
        $('#timer-display').text(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
    }

    $('#start-timer').click(function () {
        if (!timer) {
            timer = setInterval(function () {
                time++;
                updateTimerDisplay();
            }, 1000);
        }
    });

    $('#stop-timer').click(function () {
        clearInterval(timer);
        timer = null;
    });

    $('#reset-timer').click(function () {
        time = 0;
        updateTimerDisplay();
    });

    updateTimerDisplay();
});
</script>
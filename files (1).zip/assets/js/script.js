jQuery(document).ready(function ($) {
    let homeScore = 0;
    let guestScore = 0;

    $('#home-increment').click(function () {
        homeScore++;
        $('#home-score').text(homeScore);
    });

    $('#home-decrement').click(function () {
        if (homeScore > 0) homeScore--;
        $('#home-score').text(homeScore);
    });

    $('#guest-increment').click(function () {
        guestScore++;
        $('#guest-score').text(guestScore);
    });

    $('#guest-decrement').click(function () {
        if (guestScore > 0) guestScore--;
        $('#guest-score').text(guestScore);
    });
});